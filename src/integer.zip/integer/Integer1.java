package integer;

import java.util.Scanner;

public class Integer1 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("L:");
        int l= scanner.nextInt();;
        int m = l / 100;// to'liq metrlar soni

        System.out.println("M:"+m);

    }
}
