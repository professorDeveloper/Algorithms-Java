package integer;

public class integer4 {
    public static void main(String[] args) {
        int a, b;
        a = 153;
        b = 27;

        System.out.println(a / b);

    }
}
