package integer;

public class integer6 {
    public static void main(String[] args) {
        int a = 73; // 5 6
        int onlar = a / 10;  // 5
        int birlar = a % 10; // 6

        System.out.println("O`nliklar: "+onlar);
        System.out.println("Birliklar: "+birlar);

    }
}
