package array;

/**
 * Project Admin -> Husanboy Azamov
 * Package Name  -> array
 * Class Name -> Array43
 * Copyright © : 6/24/2022
 */
public class Array43 {
    public static void main(String[] args) {

    }
    public static void array43(int[]array){
        int num =1;
        for (int i=1; i< array.length; ++i) {
            num++;
        }
        System.out.println(num);
        }
}
