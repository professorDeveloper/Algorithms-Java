package fun;

public class Fun26 {
    public static void main(String[] args) {
        IsPower5(125);
    }

    public static void IsPower5(int k) {//125 =k ekranda =true =3

            int a = 2;
            int p = 1;

            for(int i=0; i<5; i++){
                p = p * a;
            }

            System.out.println(p);

    }
}
