package fun;

public class Fun25 {
    public static void main(String[] args) {
        iSquare(49);
        iSquare(47);
        iSquare(25);
        iSquare(32);
    }

    public static void iSquare(int k) {
        int a = (int) Math.sqrt(k);
        if (a == k / a) {
            System.out.println(true);
        } else {
            System.out.println(false);
        }

    }
}
