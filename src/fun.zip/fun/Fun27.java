package fun;

public class Fun27 {
    public static void main(String[] args) {
        IsPowerN(5,25);//true
        IsPowerN(5,125);//true
        IsPowerN(3,9);//true
        IsPowerN(4,12);//false
        IsPowerN(3,39);//true
    }
    public static void IsPowerN(int n, int k){
        while (k > 0) {
            k -= n;
        }
        if (k == 0) {
            System.out.print(true+"\n");
        } else {
            System.out.print(false+"\n");
        }

    }
}
