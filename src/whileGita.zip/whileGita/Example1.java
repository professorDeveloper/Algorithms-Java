package whileGita;

public class Example1 {
    public static void main(String[] args) {
        int n = 10;
        // while ishlatilishi
        int i = 1;
        while (true) {
            System.out.println(i);
            i++;
            if (i > n)
                break;
        }
    }
}
