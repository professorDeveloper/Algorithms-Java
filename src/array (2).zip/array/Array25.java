package array;

/**
 * Project Admin -> Husanboy Azamov
 * Package Name  -> array
 * Class Name -> Array25
 * Copyright © : 6/23/2022
 */
public class Array25 {
    public static void main(String[] args) {

    }
}
