package ifdirect;

import java.util.Scanner;

public class if14 {
    public static void main(String[] args) {

        Scanner scanner=new Scanner(System.in);
        System.out.println("a :");
        int a = scanner.nextInt();//3
        System.out.println("b:");
        int b = scanner.nextInt();//6
        System.out.println("C: ");
        int c = scanner.nextInt();//1
        int maxA_B=Math.max(a,b);
        int minA_B=Math.min(a,b);//3
        if (a!=b && b!=c && c!=a) {

        }

    }
}
