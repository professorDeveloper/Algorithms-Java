package ifdirect;

public class if15 {
}
