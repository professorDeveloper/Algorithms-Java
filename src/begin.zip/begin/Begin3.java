package begin;

import java.util.Scanner;

public class Begin3 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int a =scanner.nextInt();
        int b=scanner.nextInt();
        int p=2*(a+b);
        int s =a*b;
        System.out.println("P="+p);
        System.out.println("S="+s);
    }
}
