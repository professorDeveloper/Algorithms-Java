package begin;

import java.util.Scanner;

public class begin24 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int a;
        int b;
        int x;
        System.out.print("a=");
        a = scanner.nextInt();
        System.out.print("b=");
        b = scanner.nextInt();
        x = -b / a;
        System.out.print("x=");
        System.out.print(x);

    }
}
