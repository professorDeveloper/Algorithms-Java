package begin;

import java.util.Scanner;

public class begin31 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int tc=scanner.nextInt();
        int tf= (int) (tc*1.8);
        System.out.println("Tf: "+tf);
    }
}
