package uz.gita.lesson3;

public class Begin29 {
    public static void main(String[] args) {
//        double PI = 3.1415;
        double PI = Math.PI;
        double alfaGradus = 90;// ~1.57
        double alfaRadian = 2 * Math.PI * alfaGradus / 360;

        System.out.println(alfaGradus + "(gs) ~= " + alfaRadian+"(rad)");


    }
}
