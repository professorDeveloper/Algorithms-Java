package begin;

public class Begin30 {
    public static void main(String[] args) {

        double alfaRadian = Math.PI / 3; // 90
        double alfaGradus = 360 / (2 * Math.PI) * alfaRadian;

        System.out.println(alfaRadian + "(rad) ~= " + alfaGradus + "(gs)");


    }
}
