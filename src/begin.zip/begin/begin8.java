package begin;

import java.util.Scanner;

public class begin8 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("a:");
        int a=scanner.nextInt();
        System.out.println("b:");

        int b=scanner.nextInt();
        int c=(a+b)/2;
        System.out.println("O`rta Arifmetik");
    }
}
