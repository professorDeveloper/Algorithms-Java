package begin;

import java.util.Scanner;

public class Begin4 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("D:");
        int d=scanner.nextInt();
        int l = (int) (d*Math.PI);
        System.out.println("L:"+l);


    }
}
