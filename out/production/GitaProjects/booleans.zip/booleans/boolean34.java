package booleans;

import java.util.Scanner;

public class boolean34 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("1..8 x1 va y1 :");
        int x =scanner.nextInt();
        int y =scanner.nextInt();
        boolean r=true;
    }
}
