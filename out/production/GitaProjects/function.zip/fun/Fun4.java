package fun;

public class Fun4 {
    public static void main(String[] args) {

    }
}
