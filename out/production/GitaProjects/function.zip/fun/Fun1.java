package fun;

public class Fun1 {
    public static void main(String[] args) {
        System.out.println (powerA3 (2.1));
        System.out.println (powerA3 (2.1));
        System.out.println (powerA3 (2.5));
        System.out.println (powerA3 (2.9));
        System.out.println (powerA3 (2));
        System.out.println (powerA3 (3));

    }

    public static double powerA3(double n) {
        return n * n * n;
    }

    public static int powerA3(int n) {
        return n * n * n;
    }

}
