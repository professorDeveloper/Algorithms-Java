package booleans;

public class boolean36 {
}
