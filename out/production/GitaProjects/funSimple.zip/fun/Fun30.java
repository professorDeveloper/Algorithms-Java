package fun;

public class Fun30 {
    public static void main(String[] args) {

    }
}
