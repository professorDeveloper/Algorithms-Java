package fun;

public class Fun24 {
    public static void main(String[] args) {
        Even(21);
        Even(22);
        Even(23);
    }
    public static void Even(int k){
        if (k%2==0){
            System.out.println("Juft son");
        }else {
            System.out.println("Toq son");
        }
    }
}
