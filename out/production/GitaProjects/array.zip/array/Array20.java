package array;

public class Array20 {

    public static void main(String[] args) {
        int[] array = {3, 5, 1, 4, 2, 3, 1, 6, 5, 1};
        System.out.println(solution(array, 2, 7));
    }
    public static int solution(int[] array, int k, int l) {
        int sum = 0;
        for (int i = k; i <= l; i++) {
            sum += array[i];
        }
        return sum;

    }
}
