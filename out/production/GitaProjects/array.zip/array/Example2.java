package array;

public class Example2 {
    public static void main(String[] args) {
        // massivga murojaat qilish
        // 1. qiymat yozish (o'zlashtirish)
        int[] arr = new int[3];

        arr[0] = 6;
        arr[2] = -9;


        int t = arr[0];
        System.out.println(t); // 6
        String[] s = new String[100]; // indexlari -> 0,1,2,3,...,98,99

        s[5] = "Salom";
        //2. qiymatdan foydalanish (qiymatga muroajat)

        System.out.println(arr[2]); // -9
        System.out.println(arr[1]); // 0
        System.out.println(s[2]);   // null
        System.out.println(s[5]);   // Salom

    }
}
