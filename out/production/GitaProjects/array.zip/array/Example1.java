package array;

public class Example1 {
    enum Fasllar {
        YOZ,
        KUZ,
        BAHOR,
        QISH
    }

    enum PultController {
        TOP,
        RIGHT,
        LEFT,
        BOTTOM
    }

    public static void main(String[] args) {
        Fasllar fasllar = Fasllar.YOZ;
        switch (fasllar){
            case KUZ -> System.out.println("Kuz fasli");
            case QISH -> System.out.println("Qish fasli");
            case BAHOR -> System.out.println("Bahor fasli");
            case YOZ -> System.out.println("Yoz fasli");
        }


    }
}
