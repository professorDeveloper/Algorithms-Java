package array;

import java.util.Random;

public class Example4 {
    public static void main(String[] args) {
        // arrayni random sonlar bilan to'ldirish
        int n = 10;
        int[] array = new int[n];
        Random random = new Random();
        for (int i = 0; i < n; i++) {
            array[i] = random.nextInt(100); // [0;100)
        }

        for (int item : array) {
            System.out.print(item + "\t");
        }
    }
}
