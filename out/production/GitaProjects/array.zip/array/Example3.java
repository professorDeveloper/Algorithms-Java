package array;

public class Example3 {

    public static void main(String[] args) {
        int[] array = {10, 13, 26, 21, 19, 1, 2, 8, 14, 19};
        int summa = 0;
        // massiv elementlarini yig'indisini hisoblang
        for (int a : array) {
            summa += a;
        }
        System.out.println(summa);
    }
}
