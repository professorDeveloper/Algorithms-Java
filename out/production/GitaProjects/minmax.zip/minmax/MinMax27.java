package minmax;

import java.util.Scanner;

public class MinMax27 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int b = 2;
        int b2 = 2;
        int num = 0;
        int maxNum = 0;
        int maxIndex=0;
        int n;
        int index=0;
        System.out.println("n:");
        n = scanner.nextInt();
        for (int i = 1; i <= n; ++i) {
            b2 = b;
            System.out.print(i+".");
            b= scanner.nextInt();
            //
            if (b2 == b) {
                ++num;
            } else {
                if (num > maxNum) {
                    maxNum = num;
                    maxIndex = index;
                }
                index = i;
                num = 1;
            }
        }
        if (num > maxNum) {
            maxNum = num;
            maxIndex = index;
            System.out.printf("%d %d \n", maxIndex, maxNum);
        }
    }
}
