package swichcase;

public class switch11 {
    public static void main(String[] args) {

    }
}
