package whileGita;

import com.sun.source.doctree.DocTree;
import com.sun.source.doctree.DocTreeVisitor;
import com.sun.source.doctree.HiddenTree;

import java.util.ArrayList;
import java.util.List;

import static com.sun.beans.introspect.PropertyInfo.Name.hidden;

public class while13 {
    public static void main(String[] args) {


    }
}
